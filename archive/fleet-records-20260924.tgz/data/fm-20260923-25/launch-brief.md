# Task fm-20260923-25 — OpenSuperWhisper — ship — mode=local-only

## Captain's intent

Verbatim: "All features have to be explicitly shown in the UI."

He has twice concluded that delivered features do not exist because the UI never showed them — first a
tone toggle that was there in code, then a translation direction. The audit in
`firstmate-home/data/fm-20260923-14/report.md` walked 80 user-affecting behaviours and found 17 gaps; this
task closes the ones that are still open after today's merges.

## Firstmate spec — the specific gaps

_Heading renamed 2026-09-24 for consistency with the other briefs; the crew worked from this text as
"Scope"._

Close these, each as a control the user can operate or a state the user can see. Tab and section are named;
use the existing card chrome.

| id | gap | where |
|---|---|---|
| G-02 | Accessibility / keystroke-injection state invisible in Settings (the warning exists only for some trigger modes) | Shortcuts → new Permissions section |
| G-03 | Microphone permission state absent from Settings entirely | same Permissions section |
| G-04 | Speech models can be downloaded but never removed; only the transform model has a Remove control | Model tab, per row (+ size freed) |
| G-05 | Models installed on disk but not in the catalogue are never listed, so the tab can show no current model | Model tab ("Installed models (N)", "Selected model") |
| G-06 | No visible verification: transform weights verify a pinned SHA-256 silently; speech downloads are HTTP-status-checked only | Model tab rows + the transform model row ("Verified ✓" / "Verify") |
| G-07 | Silent fallback to the bundled model when the selected model file disappears (log only) | Model tab status line |
| G-10 | Delivery mechanism undescribed: label says "paste", mechanism is synthetic keystrokes, clipboard untouched, Accessibility required | Transcription → Clipboard & Paste subtitle |
| G-11 | "Debug Mode" is a visible but inert toggle (preference never read); `qwen3Variant` is a stored key with neither UI nor reader | Advanced → Debug Options — wire it or drop both |
| G-12 | `hasCompletedOnboarding` cannot be reset from the UI, so the welcome flow cannot be re-shown | Advanced |

## Explicit non-goals

- **Do not touch the Transcription → Translation & Tone card.** `fm-20260923-17` is rebuilding it right now
  (clean-up pass, glossary, English-only-model guard, detected-language display). Leave that card and the
  transform prompt path to that crew.
- Do not change defaults, the permission flow, the transform, or speech recognition behaviour. This is
  exposure: showing and operating what already exists.
- Do not add new features beyond making these visible.

## Verification

- `Scripts/dev-run.sh test` green; the app left **identity-signed and single-binary** (`codesign -d -r-`
  shows the identity requirement, never a cdhash).
- Tests must not read or write the user's preferences — `AppPreferences.defaults` is the test seam, and
  fixtures resolve their own models.
- For G-04, G-06 and G-07 especially: prove the behaviour with a real check, not a label — e.g. remove a
  downloaded model and show it is gone from disk; verify a model and show the checksum comparison; point the
  selection at a missing file and show the surfaced message. State the exact commands and output.
- Since you are editing `Settings.swift` while another crew edits one card of it: rebase on the current tip
  before finishing and keep your diff out of their card.

## Worktree isolation assertion

Work in `/Volumes/home/zenon/Projects/OpenSuperWhisper-fm-fm-20260923-15` ONLY (your existing worktree),
branch `fm/fm-20260923-15`, merged into the delivery branch already; commit on top. Never edit the primary
checkout's sources, the captain's preferences, or another crew's worktree. Do not leave an app instance
running.

## Delegation guard

You are a crew member. Do not spawn subagents. No push.

## Definition of done

Committed branch; each listed gap closed with its evidence; the non-goals respected; an honest report of
anything you could not make visible or chose to leave alone.
