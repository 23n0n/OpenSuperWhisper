# RESUME — OpenSuperWhisper fork, state at the computer restart

Written 2026-09-24, immediately before a machine restart. Nothing of ours is running; all crews were
cancelled. Nothing needs saving from memory or `/tmp` — the one artifact that mattered (the 5 GB 8B model)
was already moved to `~/models/`. A restart loses no work.

**Corrected 2026-09-24T08:20Z** against the repository and the fleet records by a later session: the
`FIRSTMATE_HOME` requirement, the unpushed state, the provenance of the suite numbers, the worktree/branch
mapping, the priority list and the cautions were added or fixed. What changed and why is recorded in the
reconcile block at the end of `FLEET-STATE.md`.

## 1. Where everything is

| what | path |
|---|---|
| app repo (the one you run) | `/Volumes/home/zenon/Projects/OpenSuperWhisper` |
| delivery branch | `feat/local-translate-tone` @ **`5e51124`**, working tree clean, **unpushed** — `origin` has no such branch, and the branch is 60 commits ahead of `origin/develop` |
| **set this first** | `export FIRSTMATE_HOME=/Volumes/home/zenon/firstmate-home`. The skill derives the home from the working directory, so a session started anywhere else reads a different fleet; that has already cost one session (2026-09-24). |
| firstmate home (state, briefs, reports) | `/Volumes/home/zenon/firstmate-home` |
| crew worktrees (preserved work below) | `/Volumes/home/zenon/Projects/OpenSuperWhisper-fm-fm-20260923-<id>` |
| built app | `<repo>/build/Build/Products/Debug/OpenSuperWhisper.app` |

## 2. How to run it again after the restart

```bash
cd /Volumes/home/zenon/Projects/OpenSuperWhisper
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer   # only needed for builds
open build/Build/Products/Debug/OpenSuperWhisper.app              # just launch what is built
./Scripts/dev-run.sh build                                        # rebuild + sign (identity)
./Scripts/dev-run.sh test                                         # build + full suite + re-sign
```
`Scripts/dev-run.sh` is the only correct entry point: it keeps `ENABLE_DEBUG_DYLIB=NO`, signs with the
identity, removes a stale split layout, and re-signs after a test run. A bare `xcodebuild test` leaves the
app **ad-hoc signed**, which silently breaks the Accessibility grant.

Expected on launch: one menu-bar app, ⌥ (hold) to record, Polish speech → Polish transcript → English typed
into the focused app.

## 3. Machine configuration as left

- Speech model: `~/Library/Application Support/ru.starmel.OpenSuperWhisper/whisper-models/ggml-large-v3-turbo.bin`
  (multilingual). Also present: `ggml-tiny.en.bin` (English-only — **never** use with language `auto`).
- Transform: **in-process** 1.5B, `~/Library/Application Support/ru.starmel.OpenSuperWhisper/transform-models/qwen2.5-1.5b-instruct-q4_k_m.gguf`
  (SHA-256 verified). `transformUseExternalEndpoint=0` — no server involved.
- Other models on disk: `~/models/Qwen3-8B-Q4_K_M.gguf` (5.03 GB, the chosen Polish-output backend),
  `~/models/Qwen3-30B-A3B-Instruct-2507-q4_k_m.gguf` (19 GB, optional maximum-quality, needs ~18 GB wired).
- Prefs that matter (`defaults read ru.starmel.OpenSuperWhisper`): `modifierOnlyHotkey=leftOption`,
  `holdToRecord=1`, `translateEnabled=1`, `toneEnabled=0`, `whisperLanguage=auto`, `selectedEngine=whisper`,
  `transformTargetLanguage` unset = English default.
- Accessibility grant: given to the **identity-signed** app (`certificate leaf = H"32266bcc…"`). If the
  indicator says keystrokes are off after the restart, the grant was invalidated with the signature —
  re-grant in System Settings; the app now warns inline instead of blocking.
- `/tmp/fm24-models/` no longer exists (the 8B model was moved to `~/models/`).

## 4. What is live in the app now

Suite state **as recorded** for the delivery tip: 381 tests, 327 passed, 0 failed, 54 skipped. Provenance,
corrected 2026-09-24: that figure was never re-executed after the final merge. It is consistent with the last
fully recorded run — 379/325/0/54 at `32aacc0` — plus the two long-form cases that `ce1619e` un-skipped, and
the arithmetic 327+54=381 holds; but treat it as credible-unreproduced until `fm-20260924-01` re-measures
it.

1. No permission gate — inline grant notices, onboarding "Skip for now"; builds can no longer launch in the
   broken split-dylib layout. Root cause proven: ad-hoc linker-signed split build vs TCC's identity
   requirement (`tccd … status: -67050` two seconds after the grant was recorded Allowed).
2. Settings sheet usable — macOS lays a `TabView`'s strip out **0×0 inside a sheet**; replaced with a
   segmented picker; sheet fits the window; snapshot test guards it.
3. Target language (English default, Polish) with pass-through when spoken == target (no model call).
4. Indicator reports "No microphone" instead of "Processing…" (guard order fixed).
5. Test isolation — per-process preference stores, fixtures resolved explicitly; tests no longer read your
   `selectedWhisperModelPath`.
6. **Long-form audio loss fixed** — `noTimestamps = !showTimestamps` (default off) made whisper.cpp advance
   the seek a full 30 s per window and discard untranscribed audio; recall measured on the crew's run as
   0.9932 EN / 0.9873 RU, and the long-form test passes with `large-v3-turbo`. **No fleet file carries that
   measurement** — `fm-20260923-23` left no `status.log` and no report, and the task row said `in-flight`
   until the 2026-09-24 reconcile. It is the flagship fix of this branch and it rested on prose;
   `fm-20260924-01` re-measures and records it.

## 5. Diagnoses and decisions that must not be re-litigated

- "The translate model is shit" was an input problem: English-only `ggml-tiny.en.bin` + language `auto`
  produced English hallucination before the transform ran. Same WAV: tiny.en → "There are some people who
  are going to go to the airport."; large-v3-turbo → "Teraz mówię po polsku i chcę, żeby była po polsku."
- Polish → English keeps the shipped 1.5B: 8/8 correct, ~0.29 s, 1.1 GB.
- **Polish output uses Qwen3-8B** (your decision): 11/15 clean, never invents, 5.33 GB wired, 3.2 s cold load,
  idle unload viable. Pinned: `https://huggingface.co/Qwen/Qwen3-8B-GGUF/resolve/main/Qwen3-8B-Q4_K_M.gguf`,
  SHA-256 `d98cdcbd03e17ce47681435b5150e34c1417f50b5c0019dd560e4882c5745785`, 5 027 783 488 bytes.
  The 30B-A3B is better (12/15, no broken grammar) **and** faster (1.04 s) but needs ~18 GB wired and a 44 s
  cold load, so it cannot honour the 10-minute idle unload.
- Unresolved: the **in-process** transform is non-deterministic (8/10 outputs differed between identical
  runs) while the same model over `llama-server` is byte-identical ×3 — the fix was cancelled mid-flight.

## 6. Work stopped mid-flight — preserved, NOT merged

| worktree (this is where the work lives) | branch @ tip | state |
|---|---|---|
| `…-fm-20260923-16` | `fm/fm-20260923-16` @ `8e8b92a` | committed: "add Settings… to the status-bar menu" + 1 uncommitted file (`OpenSuperWhisper/OpenSuperWhisperApp.swift`) |
| `…-fm-20260923-15` | `fm/fm-20260923-15` @ `5263999` | committed: G-04 remove models (space freed), G-05 installed-models list + Use/Verify/Remove + Selected line, G-06 real SHA-256 verification incl. the bundled model, G-07 fallback as a notice; 7/7 ModelStorageTests green. **This is the `fm-20260923-25` assignment** — the brief is `data/fm-20260923-25/launch-brief.md` while the branch is named `15`; that id mismatch is real, not a typo |
| `…-fm-20260923-15` (uncommitted) | — | G-02/G-03 Permissions card (Accessibility + Microphone + Open System Settings), G-10 honest "keystrokes, no clipboard" subtitle, G-11 Debug Mode wired (orphan `qwen3Variant` deleted), G-12 Welcome-Screen reset card, updated snapshot tests + `SettingsExposureTests`, and one unbuilt polish pinning the bundled model's digest — 5 entries in `git status` |
| `…-fm-20260923-17` (uncommitted only) | `fm/fm-20260923-17` @ `32aacc0` (that tip is **already merged** as the isolation follow-up) | the fm-17 assignment itself is uncommitted: 7 modified (AppErrorCenter, ContentView, WhisperEngine, IndicatorWindow, TranscriptionService, TranslationService, AppPreferences) + 3 new (`DictationReport.swift`, `Utils/DictationScrubber.swift`, `Utils/SpeechModelLanguageGate.swift`) |
| `fm/fm-20260923-09` (no worktree; branch only) | `fm/fm-20260923-09` @ `98c63fd` | one unmerged commit whose change is **already in the delivery tree** (`dev-run.sh` worktree bundle-id suffix). A duplicate — inspect it, then delete the branch; do not re-merge |
| `…-fm-20260923-{12,13,22,23,27}` | merged | land already on the delivery branch; these worktrees are inert and safe to remove once preservation (`fm-20260924-03`) is done |

None of the uncommitted sets was built or tested together; everything through G-12 was green before the last
polish. To inspect: `git -C <worktree> status` and `git -C <worktree> log --oneline -3`. The ledger
(`state/tasks.json`) carries the same mapping — verified against disk on 2026-09-24.

## 7. Open tasks, in priority order

Rewritten 2026-09-24. Every entry has a brief on disk under `data/<id>/launch-brief.md`, complete and free of
placeholders. Nothing below is dispatched. Order is project value, not agent convenience: land what is
already written, then the two captain-decided features, then coverage.

1. **fm-20260923-17** — clean-up pass (`hmm`/`aaa`/stutter scrub + grammar repair through the existing single
   transform call), glossary/reference field, English-only-model guard, detected-language + raw-vs-transformed
   display. Work written, uncommitted, never built (see §6). Worktree `…-fm-20260923-17`.
2. **fm-20260923-25** — remaining UI-exposure gaps: G-02/G-03, G-10, G-11, G-12 (written, uncommitted). Work
   in the `…-fm-20260923-15` worktree, on branch `fm/fm-20260923-15`; G-04..G-07 already committed there.
3. **fm-20260923-16** — menu-bar Settings item: the root cause of two of your "the feature does not exist"
   conclusions. Committed `8e8b92a`, one file uncommitted.
4. **fm-20260923-28** — Qwen3-8B as the Polish-output backend (your decision). After (1) and (2): same
   Settings card and model files.
5. **fm-20260923-27** — in-process determinism (the gate must not return different text for the same input);
   branch `fm/fm-20260923-27` already exists at the delivery tip.
6. **fm-20260923-26** — delivery-path coverage: 50 of the 54 suite skips are keyboard-layout-gated, so the
   path you use daily is the least covered in the suite.
7. **fm-20260924-01** — re-measure and *record* the long-form recall evidence and the suite totals on the
   delivery tip; closes the gap where the branch's flagship fix rests on prose.
8. **fm-20260924-03** — preservation: the unpushed branch, the three unlanded branches and the uncommitted
   sets all live on one disk. Independent of everything else; a local bundle is cheap insurance.
9. Optional measurement, not registered: the 14B rung (~9 GB) between the 8B and the 30B.

## 8. Cautions

- Do not run a bare `xcodebuild test` (see §2). Verify with `codesign -d -r-` that the bundle shows the
  **identity requirement**, never a bare `cdhash`.
- Do not use an English-only Whisper model with language `auto`; that is the hallucination defect.
- Crew worktrees share the app's `.dev` bundle id and (by default) one preference domain — one app instance
  at a time, and prefer `Scripts/dev-run.sh`.
- The suite's 54 skips are environmental: keyboard layouts absent, mic opt-in (`OSW_TEST_MICROPHONE=1`),
  turbo fixture opt-in (`OSW_TEST_TURBO_MODEL`), and the long-form fixture path. `fm-20260923-26` targets the
  layout-gated 50.
- **Ledger semantics after the 2026-09-24 reconcile.** `state/tasks.json` is trustworthy again, but read the
  `status` field, never the `updated` timestamp: `parked` = the captain halted the crew and the work sits
  unlanded in the row's `worktree`; `ready` = the crew finished, the work is unlanded and awaiting a merge
  decision. Two rows (`fm-20260923-15`, `fm-20260923-25`) deliberately point at the **same** worktree and
  branch.
- `fm/fm-20260923-09` carries one unmerged commit that is already in the delivery tree — a duplicate. Do not
  merge it; delete the branch when convenient.
- **Everything is on one disk.** The delivery branch is unpushed and the unlanded work exists only in the
  worktrees. `fm-20260924-03` exists because of that.
- Two fleet homes exist on this machine (`/Volumes/home/zenon/firstmate-home` — this project — and
  `/Volumes/home/zenon/Documents/deepseek_general/firstmate-home` — the other project). Always export
  `FIRSTMATE_HOME` (section 1) before reading or writing fleet state; a stale lock in the wrong home has
  already misled one session.
- Task ledger and per-task logs: `firstmate-home/state/tasks.json`, `firstmate-home/data/fm-*/status.log`,
  fleet history in `firstmate-home/data/FLEET-STATE.md`.
