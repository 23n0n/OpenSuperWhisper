# Task fm-20260924-01 — OpenSuperWhisper — scout (measure + record) — no branch

## Captain's intent

_Not raised by the captain: this is the first mate's own finding from the 2026-09-24 reconcile._

_Why it matters: the flagship fix of the branch must stop resting on prose._

## Why this exists

`fm-20260923-23` is the flagship correctness fix on the delivery branch (`5e51124`): whisper.cpp was
advancing the seek a full 30 s per window and discarding untranscribed audio, because
`noTimestamps = !showTimestamps` was true by default. The fix is in the tree (`aaddc83`, with
`LongFormTranscriptionTests.swift` rewritten) and `ce1619e` removed the calibrated-model skip from
`Scripts/dev-run.sh`.

The handoff asserts the result — *recall now 0.9932 EN / 0.9873 RU, and the suite green at 381 tests /
327 passed / 0 failed / 54 skipped* — but **no fleet file contains that evidence**: `fm-20260923-23` has no
`status.log` and no `report.md`, and the last recorded suite run in `FLEET-STATE.md` is the older
379/325/0/54 at `32aacc0`. The flagship fix currently rests on one sentence of prose.

Deliverable: `data/fm-20260924-01/report.md`, plus the corrected numbers written back into
`RESUME.md` and `FLEET-STATE.md`.

## Firstmate spec

1. **Re-establish the fixture.** `LongFormTranscriptionTests` resolves its model from
   `.build/test-models/ggml-tiny.bin` and the probe is a **size check**, so the fixture must be a **hard
   link** to a real model, not a symlink (Foundation stats the link and the size probe fails). The primary
   checkout's `.build/test-models/` is currently empty — recreate it before running anything.
2. **Run the long-form tests against the multilingual model** (`ggml-large-v3-turbo.bin`, the model the
   captain actually uses) and capture the **actual English and Russian transcripts**, not just pass/fail.
   Report the recall numbers for both languages from the run you performed, and say whether they match the
   0.9932 / 0.9873 asserted in the handoff.
3. **Record the full suite as it stands on the delivery tip**: the exact command, the totals
   (total / passed / failed / skipped) and every remaining skip's reason. Reconcile the count with the
   379/325/0/54 recorded at `32aacc0`: state the delta and explain it from the commits between the two runs.
4. **Correct the records** in place: `RESUME.md` section 4 item 6 and `FLEET-STATE.md` get the measured
   numbers with the command that produced them; the `fm-20260923-23` row in `state/tasks.json` loses the
   "EVIDENCE GAP" note if and only if the gap is now closed by your report. Write a `status.log` line for
   this task either way.
5. **Report honestly if you cannot execute.** If the measurement is not reachable — the fixture will not
   resolve, the model is absent, the run refuses to complete — say so as the deliverable's first line
   instead of substituting code inspection for a measurement. Do not run a bare `xcodebuild test`; it leaves
   the bundle ad-hoc signed and breaks the Accessibility grant.

## Worktree isolation assertion

No branch, no worktree: this task reads and measures the delivery branch in the primary checkout
`/Volumes/home/zenon/Projects/OpenSuperWhisper` and writes only under
`/Volumes/home/zenon/firstmate-home/data/fm-20260924-01/`. Do not commit source changes. Do not leave an app
instance running.

## Delegation guard

You are a crew member. Do not spawn subagents. No push. No merges.

## Definition of done

`data/fm-20260924-01/report.md` with: the command(s) run, the transcripts or recall numbers obtained, the
suite totals with skip reasons, the delta against the `32aacc0` run explained, and either the corrected
records or an explicit statement of what blocked execution.
