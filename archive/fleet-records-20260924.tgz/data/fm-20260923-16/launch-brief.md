# Task fm-20260923-16 — OpenSuperWhisper — ship — mode=local-only

## Captain's intent

The UI-exposure audit (`firstmate-home/data/fm-20260923-14/report.md`) found the reason the captain
repeatedly concluded that delivered features do not exist:

> **G-01** — the status-bar menu has no Settings item. Settings opens only from the main window's gear or
> the app menu (⌘,), so when the window is hidden there is no way into Settings at all.

Fix that gap. It is the cheapest, highest-value item in the audit and it is independent of the branches
editing `Settings.swift`.

## Firstmate spec

1. Add a **Settings…** item to the status-bar menu in `OpenSuperWhisper/OpenSuperWhisperApp.swift` (the
   only file holding the `NSStatusItem` menu), posting the existing `NotificationName+App.openSettings`
   notification — do not invent a second path to the settings view.
2. If the main window is closed or hidden when the item is used, bring it forward first (`.openSettings`
   is consumed by `ContentView`, so the view must exist); say in your report exactly how you handled that.
3. Place it sensibly among the app-level items; do not reorder the rest of the menu.
4. Nothing else: no layout, preferences, permission flow, transform or model-management changes — three
   sibling branches are editing `Settings.swift`.

## Verification

- `Scripts/dev-run.sh build` green; unit suite green (`NoMicrophoneGuardTests` is no longer a known flake:
  its one red case was deterministic, and fm-20260923-22 fixed it).
- Evidence that the item reaches Settings: a build-level check plus, if you can, an automated one (a test
  that posts the notification and asserts the settings-presenting state), or an explicit reasoning chain
  with the exact lines.
- The app bundle stays **identity-signed and single-binary** after build and after a test run
  (`codesign -d -r-` shows the identity requirement, not a cdhash).

## Worktree isolation assertion

Work in `/Volumes/home/zenon/Projects/OpenSuperWhisper-fm-fm-20260923-16` ONLY, branch
`fm/fm-20260923-16`. Initialize submodules with
`git -c protocol.file.allow=always submodule update --init --recursive`. Never edit the primary checkout's
sources, the captain's preferences, or any other worktree. Do not leave an app instance running.

## Delegation guard

You are a crew member. Do not spawn subagents. No push.

## Definition of done

Committed branch with the menu item; build and suite green; a short honest report of the diff, the
evidence, and anything unverified.
