# Backlog

Reconciled 2026-09-24 against the delivery branch `feat/local-translate-tone` @ `5e51124` (working tree
clean, unpushed). Ledger: `state/tasks.json`. Handoff: `data/RESUME.md`.

## Open — priority order (project value; agent-session constraints are not project work)

1. **fm-20260923-17** ship — clean-up pass (`hmm`/`aaa`/stutter scrub, grammar repair), glossary/reference
   field, English-only-model guard, detected-language + raw-vs-transformed display. Ten uncommitted files
   sit in `OpenSuperWhisper-fm-fm-20260923-17`; never built or tested.
2. **fm-20260923-25** ship — remaining UI-exposure gaps G-02/G-03 (permission state), G-10 (keystroke
   delivery described honestly), G-11 (inert Debug toggle), G-12 (onboarding reset). G-04..G-07 are
   committed at `5263999`; the rest are uncommitted in the same worktree.
3. **fm-20260923-16** ship — Settings item in the status-bar menu (`8e8b92a` + one uncommitted file). Root
   cause of two of the captain's "feature does not exist" conclusions.
4. **fm-20260923-28** ship — Qwen3-8B as the Polish-output backend (captain's decision, digest pinned in the
   brief). Sequence after fm-17 and fm-25: same Settings card and model files.
5. **fm-20260923-27** ship — in-process transform must be deterministic (same input, same output). Brief
   written; branch `fm/fm-20260923-27` already exists at the delivery tip.
6. **fm-20260923-26** ship — layout-independent delivery test: 50 of the 54 suite skips are input-source
   layout gated, i.e. the path the captain uses daily is the least covered.
7. **fm-20260924-01** scout — re-measure and **record** the fm-20260923-23 long-form evidence (recall EN/RU
   with `large-v3-turbo`) and the suite totals on the delivery tip. The flagship fix currently rests on a
   sentence of prose.
8. **fm-20260924-03** ops — preservation: the unpushed branch, three unlanded branches and three worktrees of
   uncommitted work all live on one disk; a branch-only backup would drop exactly the uncommitted sets.
9. Optional measurement — the 14B rung (~9 GB) between the 8B and the 30B-A3B. Not registered.

## Shipped — merged into the delivery branch, do not re-litigate

- `fm-20260923-01` .. `-05`: local PL->EN transform, keypress output (clipboard untouched), language-aware
  gate, independent tone switch, local transform backend.
- `fm-20260923-08`: one-package delivery — vendored llama.cpp on a single unified ggml, in-process runtime,
  app-managed sha256 model download, `.pkg` plus one idempotent uninstall.
- `fm-20260923-09`, `-10`, `-11`: identity-based dev signing, Input Monitoring dropped, end-to-end delivery
  proof.
- `fm-20260923-12`, `-13`, `-21`: no permission gate + inline notices, target-language control, per-process
  test preference store.
- `fm-20260923-15` (layout half), `-22`, `-20`: Settings sheet legible and clickable, the "mic absent" bug
  called a flake and then fixed properly, the long-form loss proven a test artefact.
- `fm-20260923-23`: long-form audio loss fixed (`noTimestamps` default) — the delivery tip's merge.
- `fm-20260923-18` was folded into `fm-20260923-17`; it was never a separate task.

## Landed but not evidenced in the fleet records

- `fm-20260923-23` has no `status.log` and no report. The recall figures quoted in `RESUME.md` section 4
  item 6 (0.9932 EN / 0.9873 RU) appear in no other file on disk. `fm-20260924-01` closes this.

## Preserved, not merged

- `OpenSuperWhisper-fm-fm-20260923-15` — branch `fm/fm-20260923-15` @ `5263999` + 5 uncommitted files.
- `OpenSuperWhisper-fm-fm-20260923-16` — branch `fm/fm-20260923-16` @ `8e8b92a` + 1 uncommitted file.
- `OpenSuperWhisper-fm-fm-20260923-17` — 7 modified + 3 new files, uncommitted.
- `fm/fm-20260923-09` — one unmerged commit whose change is already in the delivery tree (duplicate).
- Merged worktrees still on disk and safe to remove: `-12`, `-13`, `-22`, `-23` (and `-27`, which is the
  empty branch for the determinism task).

## Machine configuration as left

Speech model `ggml-large-v3-turbo.bin` (multilingual) — never `ggml-tiny.en.bin` with language `auto`;
transform in-process 1.5B, `transformUseExternalEndpoint=0`. Details and the caution list live in
`RESUME.md` sections 3 and 8.
