# Task fm-20260923-17 — OpenSuperWhisper — ship — mode=local-only

Owns three things the captain demanded in sequence: the English-only-model guard, the dictation clean-up
pass, and a reference/glossary. They live in the same prompt composition and the same Settings card, so
one crew owns all three rather than racing three branches through one function.

## Captain's intent

1. Verbatim: "A translate feature is basically shit… it does actually random sentence in English… Just
   random sentences in English." Root cause proven: his selected speech model was `ggml-tiny.en.bin`
   (English-only) with language `auto`, so Whisper hallucinated English and the transform correctly found
   nothing to translate. Nothing warned him; nothing showed him the model or the language in play.
2. Verbatim: "There is even nothing to provide it reference."
3. Verbatim: "I was thinking about adding at least one additional feature to basically scrub all the
   'hmmmm', 'aaaaa' and other artifacts and make the language a little bit polish. So basically correct
   the grammar… adding the 'a' when it's needed and maybe fixing the word's order to form proper
   sentences in English."

## Firstmate spec

1. **Refuse the impossible combination.** An English-only speech model (filename ending `.en.bin`, or
   `whisper_is_multilingual() == 0`) with `whisperLanguage != "en"` must never silently produce a
   transcript. Surface it inline, naming the model and the language setting, with the fix available in
   place (a multilingual model — `ggml-large-v3-turbo.bin` is already on this machine). Do not block
   plain English dictation, and never silently change the user's selected model.
2. **Show the pipeline per dictation.** `WhisperEngine.reportedLanguage` and the transform policy already
   exist — expose them: after each dictation show the detected language and, when the transform ran, the
   raw transcript beside the transformed text. History keeps the raw text; make the pair visible.
3. **Clean-up pass** (the captain's new feature). Two layers, in this order:
   - **Deterministic scrub** — remove disfluencies and artifacts the recogniser emits: repeated filler
     tokens ("hmm", "uh", "yyy", "aaa", "eee"), stutters and immediate word repetitions, false starts,
     stray non-lexical noise. Conservative: never delete a word that carries meaning; Polish and English
     fillers both. This layer must be unit-testable with fixed inputs, no model needed.
   - **Grammar repair via the transform** — fold into the *existing single* transform call (never a second
     model call): restore punctuation and capitalisation, add missing articles ("a"/"the"), fix word order
     and agreement to form proper sentences in the output language, without adding or dropping meaning.
   Visible as its own control in Settings → Transcription (e.g. "Clean up dictation: remove filler words
   and fix grammar"), on by default is acceptable if the measurement below justifies it. It must apply to
   Polish → Polish (translation off) as well as to the translated direction.
4. **Reference/glossary.** A user-editable field (names, jargon, domain terms) fed into the transform
   prompt, persisted as a preference, visible in the same card. Optional, empty by default, and it must
   not disturb the prompt when empty.
5. Confine the diff to the recognition path, the transform path and the Transcription tab of
   `Settings.swift`. `fm-20260923-15` is fixing that file's layout — rebase before touching the card.

## Measurement required before wiring the grammar layer

Take 8–10 real dictations (the captain's own recordings are on disk under
`~/Library/Application Support/ru.starmel.OpenSuperWhisper/recordings/` with the matching rows in
`recordings.sqlite`) and show, for each: raw transcript → cleaned transcript → final output, in both the
Polish → English and English → Polish directions, with latency. State honestly whether the 1.5B model
improves or degrades the text; if it fabricates or drops meaning, say so with the example and keep the
deterministic layer only until a stronger model is chosen.

## Verification

- `Scripts/dev-run.sh build` green; unit suite green (`NoMicrophoneGuardTests` is no longer a known flake:
  its one red case was deterministic, and fm-20260923-22 fixed it).
- Tests or harness proving: (a) English-only + auto is surfaced/refused rather than passed through;
  (b) the deterministic scrub on fixed inputs; (c) the glossary and clean-up instructions reach the
  composed prompt — assert the composed prompt, not the plumbing; (d) detected-language and
  raw-vs-transformed state is produced for a real fixture.
- The app bundle stays **identity-signed and single-binary** after build and after a test run
  (`codesign -d -r-` must show the identity requirement, not a cdhash).

## Worktree isolation assertion

Work in `/Volumes/home/zenon/Projects/OpenSuperWhisper-fm-fm-20260923-17` ONLY, branch
`fm/fm-20260923-17`, from the delivery tip at dispatch time. Initialize submodules with
`git -c protocol.file.allow=always submodule update --init --recursive`. Never edit the primary
checkout's sources, the captain's preferences, or any other worktree. Do not leave an app instance running.

## Delegation guard

You are a crew member. Do not spawn subagents. No push.

## Definition of done

Committed branch; the three behaviours implemented and proven; the measurement table; an honest report of
quality, of anything unverified, and of anything you deliberately left out.
