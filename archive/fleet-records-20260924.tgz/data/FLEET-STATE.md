# Fleet state — OpenSuperWhisper voice keyboard (single source of truth)

Updated: 2026-09-23. Repo: `/Volumes/home/zenon/Projects/OpenSuperWhisper` (fork of Starmel/OpenSuperWhisper).
Delivery branch: `feat/local-translate-tone`. Fleet home: `/Volumes/home/zenon/firstmate-home`.

## Captain's asks (all of them)
1. Local Polish→English translation + tone adjustment + delivery by simulated keystrokes (clipboard untouched).
2. Language awareness: English dictation must never be translated; Polish translates only when switched on.
3. Tone must have its own user toggle, independent of translation.
4. One package: install and uninstall in a single idempotent operation, nothing connected by goodwill.
5. Press-and-hold push-to-talk: press a key to start recording, release to stop.
6. Input Monitoring permission must not be required.
7. Ship only finished, verified work; report once at the end.

## Landed on the delivery branch (verified)
- `81d892b` dev signing: `Scripts/dev-signing-identity.sh` (self-signed `OpenSuperWhisper Local Dev`, own keychain), `Scripts/dev-sign.sh` (identity-based Designated Requirement, survives rebuilds), `Scripts/dev-run.sh` (build with `ENABLE_DEBUG_DYLIB=NO`, sign, run).
- `faec335` language-aware gate + two switches: `Utils/LanguageDetector.swift`, `TransformPolicy` table, optional-tone prompts, `toneEnabled` pref (default false, no migration), engine `fullLangId` plumbing, Readme table. `transformIfEnabled(_:sourceLanguage:)` keeps its never-throws contract; recordings still saved raw before transform.
- `f9c2f00` (merge of fm-08): vendored llama.cpp on a single unified ggml, in-process runtime (`OpenSuperWhisper/Llama/Llama.swift`, `TransformRuntime.swift`), app-managed sha256 model download (`TransformModelManager.swift`), packaging (`packaging/build-pkg.sh`, `distribution.xml`, `uninstall.sh`, `preinstall`), uninstall service + Settings/Advanced entry point, `Scripts/build-native.sh`, `Scripts/verify-packaging.sh`, CI updated, libomp coupling removed, `ggml-tiny.en.bin` bundled.
- Model: `Qwen2.5-1.5B-Instruct-Q4_K_M` (986 MB, sha256 `1adf0b11…6c3370`); pre-seeded at
  `~/Library/Application Support/ru.starmel.OpenSuperWhisper/transform-models/qwen2.5-1.5b-instruct-q4_k_m.gguf`.
- Evidence: unit suite 286 passed / 1 red case (`NoMicrophoneGuardTests` — deterministic, long mislabelled a "mic-state dependent flake"; root cause found and fixed by fm-20260923-22); packaging harness 39/39; contract harness 162/162; in-process decode proven by `LlamaRuntimeIntegrationTests` 3/3 against real weights (Metal 0.25 s/transform, RSS 1.32 GB warm; CPU-only 2.27 GB).

## Open / in flight

> **Superseded 2026-09-24.** Nothing in this fleet is running. Every item below either landed on the
> delivery branch or was cancelled at the captain's halt; `fm-20260923-10` completed at 15:25Z on 09-23.
> See the reconcile block at the end of this file for the corrected state.

- `fm-20260923-10` (crew, running): (a) keystrokes stop after the first dictation — instrument live Accessibility trust, log each dictation, prove mechanism A (trust lost) vs B (state machine), fix; (b) remove the Input Monitoring requirement by replacing the listen-only `flagsChanged` tap in `ModifierKeyMonitor.swift:139` with an Accessibility-gated implementation; (c) distinct bundle id for dev/CI builds; (d) fix the "Apply tone" caption that wrongly says Polish is never toned.
- Trigger semantics for press-and-hold: `ModifierKeyMonitor` + `ShortcutManager.handleKeyDown/Up` with `holdThreshold` 0.3 s — press starts, release after 0.3 s stops, quick tap toggles. Set `modifierOnlyHotkey = leftOption`, `holdToRecord = true`. Key-combination mode cannot stop on release; a held key *combination* would need a code change.
- Captain's live prefs: `translateEnabled = 1`, `toneEnabled = 1` (formal), `whisperLanguage = auto`, `selectedWhisperModelPath` = Turbo V3 in app-owned storage, `transformModel = qwen2.5-1.5b-instruct-q4_k_m`, `modifierOnlyHotkey` to be set to `leftOption`.

## Known traps (do not repeat)
- `run.sh` builds unsigned; use `Scripts/dev-run.sh`, otherwise the Accessibility grant dies on rebuild.
- Multiple copies with the same bundle id poison the TCC list; crew/test builds must use a different bundle id.
- `llama_tokenize` returns the required capacity as a negative number — never feed it to `Array(repeating:count:)`.
- `feat/local-translate-tone` has diverged from crew branches twice; use `--no-ff` merges and expect Readme conflicts.
- The commercial `Superwhisper` app runs alongside and is easily mistaken for this fork (its Settings has no Translation & Tone section).
- The HTTP backend (`Scripts/transform-server.sh`, port 1919) is now optional — the app runs inference in-process.

## Final state (2026-09-23, delivery tip 550d9d1)

- App built and signed (identity DR, cert leaf 32266bcc…), running from the primary checkout; Debug VAD abort fixed per-configuration (llamafile kernels off in Debug only, Release unchanged).
- Verification: 357 unit tests executed, 0 failures, 58 skipped (serial Debug); packaging harness 39/39 on Debug and Release apps; external-endpoint contract 162/162; uninstall proven in scratch roots 25/25 twice and with the app absent; Release .pkg built (87 MB, unsigned — 0 signing identities on this machine).
- In-process transform: llama.cpp vendored on one unified ggml; Qwen2.5-1.5B-Instruct Q4_K_M staged in app-owned storage with a verified stamp; transform 0.19-1.0 s, RSS ~1.27 GB with both engines warm.
- Captain settings: hold Left Option to record, release to stop; translation on; tone off; language Auto-detect; Turbo V3 multilingual model.
- Input Monitoring is no longer used or required anywhere (no IOHID symbols in the binary). Accessibility is the only event-related grant.
- The HTTP transform server is stopped; the app no longer needs it.
[2026-09-23T18:25:38Z] full suite on the merged tip 32aacc0: 379 total, 325 passed, 0 failed, 54 skipped, result Passed, exit 0, app identity-signed. Skips accounted: ClipboardUtilPasteIntegrationTests (35) + ClipboardUtilKeyboardLayoutTests (9) + KeyboardLayoutProviderTests (6) skip when an input-source layout (US/Dvorak/Russian/...) is not installed on this machine; PCMRecordingTests (1) needs OSW_TEST_MICROPHONE=1 + mic authorization; WhisperTurboRegressionTests (2) needs OSW_TEST_TURBO_MODEL; WhisperLongFormLanguageIntegrationTests skipped by the calibrated-model guard. Registered fm-26: the delivery path (synthetic keystrokes) deserves a layout-independent test using the active input source, since 50 of the 54 skips are layout-gated.

## [2026-09-24T05:30:54Z] STOP — captain called a halt

All crews cancelled (fm-20260923-16, -17, -27) and fm-20260923-15 told to stop and commit nothing further.
All crew app instances killed; no model servers left bound; the captain's app instance (pid 99430) is
running on the delivery tip. Delivery tip: 5e51124 on feat/local-translate-tone, working tree clean.

### Preserved mid-flight work (NOT merged, recoverable)
- fm/fm-20260923-16: 8e8b92a "feat(menu): add Settings… to the status-bar menu" + 1 uncommitted file
  (OpenSuperWhisperApp.swift) in worktree OpenSuperWhisper-fm-fm-20260923-16.
- fm/fm-20260923-15 (fm-25 assignment): 5263999 "feat(settings): show and manage the speech models that
  are on disk (G-04, G-05, G-06, G-07)" in worktree OpenSuperWhisper-fm-fm-20260923-15.
- fm/fm-20260923-17 (clean-up + glossary + guard, uncommitted): 7 modified + 3 new files in worktree
  OpenSuperWhisper-fm-fm-20260923-17 — AppErrorCenter, ContentView, WhisperEngine, IndicatorWindow,
  TranscriptionService, TranslationService, AppPreferences; new: DictationReport.swift,
  Utils/DictationScrubber.swift, Utils/SpeechModelLanguageGate.swift.
- fm/fm-20260923-27 (determinism): no changes made.

### Corrected inventory from the crews at the halt (from fm-20260923-15)
- Committed on fm/fm-20260923-15: 5263999 — G-04 Remove per row with space freed (both engines), G-05
  Installed models (N) + in-use marker + Use/Verify/Remove + Selected model line, G-06 real sha256
  verification against the digests Hugging Face publishes (pinned in the catalogue), G-07 fallback as a
  notice instead of a print. Was green: 7/7 ModelStorageTests. NOT merged.
- Uncommitted in that worktree: G-02/G-03 (Permissions card atop the Shortcuts tab: Accessibility +
  Microphone state + Open System Settings), G-10 (Clipboard & Paste subtitle: keystrokes, no clipboard,
  Accessibility required), G-11 (Debug Mode wired through Settings.debugMode into WhisperFullParams;
  orphan qwen3Variant key deleted), G-12 (Advanced → Welcome Screen card resetting hasCompletedOnboarding),
  updated SettingsLayoutSnapshotTests rendering every tab whole, and SettingsExposureTests (2 tests, green),
  plus a last unbuilt polish pinning the bundled model's published digest so Verify covers it.
- Not done because of the halt: that last polish and the four uncommitted files were never built or tested
  together, and no rebase/test/sign pass was run on them.
- fm/fm-20260923-16: 8e8b92a (menu Settings…) committed + OpenSuperWhisperApp.swift uncommitted.
- fm/fm-20260923-17: uncommitted as recorded above (clean-up, glossary, guard, language display).

## [2026-09-24T08:20:00Z] RECONCILE — handoff corrected against disk

Written by a session that started in a different working directory, found this fleet by search, and verified
every claim below against the repository. Nothing was merged, pushed, or deleted; no app or crew was started.

**Verified facts (delivery tip `5e51124` on `feat/local-translate-tone`, working tree clean, 160 tracked
files, 60 commits ahead of `origin/develop`)**

- Every commit this file claims as landed is an ancestor of the tip: `81d892b`, `faec335`, `f9c2f00`,
  `bd5ad0e`, `92fc012`, `4d1e281`, `93978c8`, `2a2c213`, `95c7e2c`, `aaddc83`, `ce1619e`.
- 12 of 15 local `fm/*` branches are merged. Exactly three are not: `fm-15` (`5263999` + 5 uncommitted
  files), `fm-16` (`8e8b92a` + 1 uncommitted), `fm-09` (`98c63fd`, a duplicate whose change is already in
  the delivery tree via `dev-run.sh`).
- The preserved mid-flight inventory matched the worktrees file-for-file: fm-16 = 1 dirty entry; the
  fm-15/fm-25 worktree = 3 modified + 1 modified test + 1 new test; fm-17 = 7 modified + 3 new; fm-27 = no
  changes at all.
- The delivery branch is **unpushed**: `git ls-remote origin` carries no `feat/local-translate-tone`.

**Corrections made to the records**

- `state/tasks.json`: 31 rows after reconcile. `fm-20260923-23` was `in-flight` while its merge was the
  delivery tip — now `done` and pointing at its worktree/branch. `fm-15`/`fm-25` were `parked`/`done` with no
  worktree recorded — both now `ready` and pointing at the SAME worktree and branch, with the id collision
  stated. `fm-16`/`fm-17` were `in-flight` — now `parked` with their real worktrees. `fm-09` carries a note
  that its unmerged commit is a duplicate. `fm-18` registered as folded into `fm-17`. Missing briefs closed:
  `fm-26`, `fm-27`, `fm-28` and the three new tasks below now have real briefs (fm-27/28 previously held the
  unfilled `{TASK}` template, which is not dispatchable).
- `data/RESUME.md`: added the `FIRSTMATE_HOME` requirement, the unpushed state,
  corrected provenance for the suite numbers (§4), the corrected worktree/branch mapping (§6), a
  rewritten priority list (§7), and four new cautions (§8).
- `data/backlog.md`: rewritten to reality — the shipped entries marked shipped, the open ones in priority
  order, the fm-23 evidence gap stated.

**New tasks registered (2026-09-24; briefs written, nothing dispatched; one withdrawn — see below)**

- `fm-20260924-01` scout — re-measure and RECORD the fm-23 long-form evidence and the suite totals on the
  delivery tip. `fm-20260923-23` left no `status.log` and no report; the recall figures 0.9932 EN / 0.9873 RU
  quoted in RESUME exist in no other fleet file.
- `fm-20260924-02` ops — **WITHDRAWN the same day, by the captain's correction**: it recorded the agent
  session's own sandbox limit as a project task and put it at the top of the queue. The project builds in a
  normal terminal; how an agent session happens to be sandboxed is not project work. The observation itself
  is kept here for the record only: inside an omp sandboxed session `/Applications` is not readable, so
  `xcodebuild` cannot run and `Scripts/dev-run.sh` dies with `CMake Error: Xcode 1.5 not supported` after
  `xcrun` fails to `dlopen` `libxcrun.dylib`. Nothing in the project's build documentation was changed for
  it, and no build path was altered. This is a fact about the agent runtime, not about the fork.
- `fm-20260924-03` ops — preservation: the unpushed branch, three unlanded branches and three worktrees of
  uncommitted work all live on one disk, and a branch-only backup would drop the uncommitted sets.

**Suite numbers, provenance corrected**

This file's last recorded run is 379 total / 325 passed / 0 failed / 54 skipped at `32aacc0`. RESUME's
381/327/0/54 is consistent with that plus the two long-form cases `ce1619e` un-skipped (327+54=381), but it
was never re-executed after the final merge and could not be re-executed on 2026-09-24. Treated as
credible-unreproduced until `fm-20260924-01` measures it.

**Operational notes**

- The fleet lock was stale (owner pid 2725, dead since 09-23); reclaimed on 2026-09-24 and re-held.
- A second fleet home exists at `Documents/deepseek_general/firstmate-home`. The skill derives the home from
  the working directory, so any session that does not export `FIRSTMATE_HOME` may read the wrong fleet.
